package application;

public class Product {

    private int id;
    private String name;
    private String type;
    private int stock;
    private double price;
    private String date;
    private String status;

    public Product(int id, String name, String type, int stock, double price, String date, String status) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.stock = stock;
        this.price = price;
        this.date = date;
        this.status = status;
    }

    // ID
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    // Name
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // Type
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    // Stock
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    // Price
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    // Date
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    // Status
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
