
package application;




import static javafx.stage.Modality.NONE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.prefs.Preferences;
import java.sql.PreparedStatement;



import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.DoubleStringConverter;


import application.Customer;
import application.Item;
import application.User;
import application.Item;


public class Main extends Application {
	
	private ArrayList<Item> itemData;
    private ObservableList<Item> itemDataList;
    
    private ArrayList<Customer> customerData;		
    private ObservableList<Customer> customerDataList;
	
	
	private TableView<Customer> tableViewcustomer;
	private TableView<Product> tableViewproduct;
	
	TableView<Item> tableView = new TableView<Item>();
	private String dbURL;
	private String dbUsername = "root";
	private String dbPassword = "root123";
	private String URL = "127.0.0.1";
	private String port = "3306";
	private String dbName = "online_supermarket";
	private Connection con;
	
	




	

	@Override
	public void start(Stage primaryStage) throws SQLException {
		showLoginPage(primaryStage);
	}
	
	private void showLoginPage(Stage primaryStage) {
		AnchorPane root = new AnchorPane();
		root.setPrefSize(833, 471);
		root.setStyle("-fx-background-color: #2D3447;");

		TextField usernameField = new TextField();
		usernameField.setLayoutX(302.0);
		usernameField.setLayoutY(189.0);
		usernameField.setPrefHeight(37.0);
		usernameField.setPrefWidth(230.0);
		usernameField.setPromptText("Enter Your Username");
		usernameField.setFont(new Font(18.0));

		PasswordField passwordField = new PasswordField();
		passwordField.setLayoutX(302.0);
		passwordField.setLayoutY(255.0);
		passwordField.setPrefHeight(37.0);
		passwordField.setPrefWidth(230.0);
		passwordField.setPromptText("Enter Your Password");
		passwordField.setFont(new Font(18.0));
		
		String[] savedCredentials = loadCredentials();
		if (!savedCredentials[0].isEmpty() && !savedCredentials[1].isEmpty()) {
			usernameField.setText(savedCredentials[0]);
			passwordField.setText(savedCredentials[1]);
		}
		

		Button signUpButton = new Button("Sign Up");
		signUpButton.setLayoutX(707.0);
		signUpButton.setLayoutY(29.0);
		signUpButton.setPrefHeight(37.0);
		signUpButton.setPrefWidth(102.0);
		signUpButton.setStyle("-fx-background-color: #151928;");
		signUpButton.setTextFill(javafx.scene.paint.Color.WHITE);
		signUpButton.setFont(new Font(18.0));

		Hyperlink  forgetPasswordLink = new Hyperlink ("Forget Your Password?");
		forgetPasswordLink.setLayoutX(302.0);
		forgetPasswordLink.setLayoutY(369.0);
		forgetPasswordLink.setPrefHeight(37.0);
		forgetPasswordLink.setPrefWidth(230.0);
		forgetPasswordLink.setStyle("-fx-background-color: #2D3447;");
		forgetPasswordLink.setTextFill(javafx.scene.paint.Color.web("#a0a2ab"));

		Button loginButton = new Button("Login");
		loginButton.setLayoutX(430.0);
		loginButton.setLayoutY(308.0);
		loginButton.setPrefHeight(37.0);
		loginButton.setPrefWidth(102.0);
		loginButton.setStyle("-fx-background-color: #2196f3;");
		loginButton.setFont(new Font(18.0));

		ImageView userIcon = new ImageView(new Image("file:resources/vector-sign-of-user-icon.jpg"));
		userIcon.setFitHeight(68.0);
		userIcon.setFitWidth(38.0);
		userIcon.setLayoutX(238.0);
		userIcon.setLayoutY(190.0);
		userIcon.setPickOnBounds(true);
		userIcon.setPreserveRatio(true);

		ImageView padlockIcon = new ImageView(new Image("file:resources/padlock.png"));
		padlockIcon.setFitHeight(39.0);
		padlockIcon.setFitWidth(38.0);
		padlockIcon.setLayoutX(238.0);
		padlockIcon.setLayoutY(256.0);
		padlockIcon.setPickOnBounds(true);
		padlockIcon.setPreserveRatio(true);

		ImageView logoImage = new ImageView(
				new Image("file:resources/Free-Super-Market-PSD-Logo-Template-Download-scaled.jpg"));
		logoImage.setFitHeight(150.0);
		logoImage.setFitWidth(200.0);
		logoImage.setLayoutX(317.0);
		logoImage.setLayoutY(14.0);
		logoImage.setPickOnBounds(true);
		logoImage.setPreserveRatio(true);

		CheckBox rememberMeCheckBox = new CheckBox("Remember Me");
		rememberMeCheckBox.setLayoutX(302.0);
		rememberMeCheckBox.setLayoutY(318.0);
		rememberMeCheckBox.setTextFill(javafx.scene.paint.Color.web("#a0a2ab"));
		rememberMeCheckBox.setFont(new Font(14.0));
		
	//	 ArrayList<String> rememberMeList = new ArrayList<>();
	//	 if(rememberMeList.contains(usernameField.getText())) {
	//		 
	//	 }
		 
		 
		 
		loginButton.setOnAction(event-> {
			 String username = usernameField.getText().trim();
			 String password = passwordField.getText().trim();

			  //  if(rememberMeCheckBox.isSelected()) {
				//	 rememberMeList.add(username);
				//    }
				 try {
					if (checkValidUser(username, password) && isAdmin(username)) {
						if (rememberMeCheckBox.isSelected()) {
							saveCredentials(username, password);
						}	
							showSuperMarketManagement(primaryStage);
							
 //   showAlert("Login successful!");
} else if(!checkValidUser(username, password)) {
	showAlert("Invalid username or password.");
} else	{
	if (rememberMeCheckBox.isSelected()) {
		saveCredentials(username, password);
	}	
	showUserScreen(primaryStage, username);	
					
}
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			    
			    
		});
		
		signUpButton.setOnAction(event -> openSignUpPage(primaryStage));
		forgetPasswordLink.setOnAction(event -> {
			String username = usernameField.getText().trim();
			try {
				if(checkUsernameExists(username)) {
					openForgetPasswordPage(primaryStage, username);
				}
				else 
				    showAlert("Invalid username.");
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			});

		root.getChildren().addAll(usernameField, passwordField, signUpButton, forgetPasswordLink, loginButton,
				userIcon, padlockIcon, logoImage, rememberMeCheckBox);

		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Login Form");
		primaryStage.show();
	}
	
	

	private void openSignUpPage(Stage primaryStage) {
		AnchorPane signUpRoot = new AnchorPane();
		signUpRoot.setPrefSize(600, 400);
		signUpRoot.setStyle("-fx-background-color: #2D3447;");

		TextField usernameField = new TextField();
		usernameField.setLayoutX(200.0);
		usernameField.setLayoutY(50.0);
		usernameField.setPrefHeight(37.0);
		usernameField.setPrefWidth(200.0);
		usernameField.setPromptText("Enter Your Username");
		usernameField.setFont(new Font(18.0));

		PasswordField passwordField = new PasswordField();
		passwordField.setLayoutX(200.0);
		passwordField.setLayoutY(100.0);
		passwordField.setPrefHeight(37.0);
		passwordField.setPrefWidth(200.0);
		passwordField.setPromptText("Enter Your Password");
		passwordField.setFont(new Font(18.0));

		TextField emailField = new TextField();
		emailField.setLayoutX(200.0);
		emailField.setLayoutY(150.0);
		emailField.setPrefHeight(37.0);
		emailField.setPrefWidth(200.0);
		emailField.setPromptText("Enter Your Email");
		emailField.setFont(new Font(18.0));

		TextField addressField = new TextField();
		addressField.setLayoutX(200.0);
		addressField.setLayoutY(200.0);
		addressField.setPrefHeight(37.0);
		addressField.setPrefWidth(200.0);
		addressField.setPromptText("Enter Your Address");
		addressField.setFont(new Font(18.0));

		TextField phoneField = new TextField();
		phoneField.setLayoutX(200.0);
		phoneField.setLayoutY(250.0);
		phoneField.setPrefHeight(37.0);
		phoneField.setPrefWidth(200.0);
		phoneField.setPromptText("Enter Your Phone");
		phoneField.setFont(new Font(18.0));
		
		Button backButton = new Button("Back");
		backButton.setLayoutX(20.0);
		backButton.setLayoutY(20.0);
		backButton.setPrefHeight(37.0);
		backButton.setPrefWidth(80.0);
		backButton.setStyle("-fx-background-color: #ff6347;");
		backButton.setFont(new Font(18.0));
		backButton.setOnAction(event -> showLoginPage(primaryStage));

		Button registerButton = new Button("Register");
		registerButton.setLayoutX(250.0);
		registerButton.setLayoutY(300.0);
		registerButton.setPrefHeight(37.0);
		registerButton.setPrefWidth(100.0);
		registerButton.setStyle("-fx-background-color: #2196f3;");
		registerButton.setFont(new Font(18.0));
		
		
		registerButton.setOnAction(event -> {
		    try {
		        String username = usernameField.getText().trim();
		        String email = emailField.getText().trim();
		        String password = passwordField.getText().trim();
		        String address = addressField.getText().trim();

		        if (username.isEmpty()) {
		            showAlert("Username cannot be empty.");
		            return;
		        } else if (email.isEmpty()) {
		            showAlert("Email cannot be empty.");
		            return;
		        } else if (password.isEmpty()) {
		            showAlert("Password cannot be empty.");
		            return;
		        } else if (address.isEmpty()) {
		            showAlert("Address cannot be empty.");
		            return;
		        } else if (checkUsernameExists(username)) {
		            showAlert("Username is used.");
		            return;
		        } else {
		            connectDB();
		            String sql = "INSERT INTO user (uname, uemail, upassword, uaddress) VALUES (?, ?, ?, ?)";
		            PreparedStatement pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, username);
		            pstmt.setString(2, email);
		            pstmt.setString(3, password);
		            pstmt.setString(4, address);
		            pstmt.executeUpdate();
		            con.close();
		            showAlert("User registered successfully!");
					showLoginPage(primaryStage);
		            
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		        showAlert("Registration failed: " + e.getMessage());
		    } catch (ClassNotFoundException e) {
		        e.printStackTrace();
		        showAlert("Driver not found: " + e.getMessage());
		    }
		});
		
	
		signUpRoot.getChildren().addAll(usernameField, passwordField, emailField, addressField, phoneField,
				registerButton,backButton);
	
		Scene signUpScene = new Scene(signUpRoot);
		primaryStage.setScene(signUpScene);
		primaryStage.setTitle("Sign Up");
	}
	
	
	
	private void openForgetPasswordPage(Stage primaryStage, String username) {
		AnchorPane forgetPasswordRoot = new AnchorPane();
		forgetPasswordRoot.setPrefSize(600, 400);
		forgetPasswordRoot.setStyle("-fx-background-color: #2D3447;");

		TextField oldPasswordField = new TextField();
		oldPasswordField.setLayoutX(200.0);
		oldPasswordField.setLayoutY(100.0);
		oldPasswordField.setPrefHeight(37.0);
		oldPasswordField.setPrefWidth(200.0);
		oldPasswordField.setPromptText("Enter Your Old Password");
		oldPasswordField.setFont(new Font(18.0));

		TextField newPasswordField = new TextField();
		newPasswordField.setLayoutX(200.0);
		newPasswordField.setLayoutY(150.0);
		newPasswordField.setPrefHeight(37.0);
		newPasswordField.setPrefWidth(200.0);
		newPasswordField.setPromptText("Enter Your New Password");
		newPasswordField.setFont(new Font(18.0));

		Button submitButton = new Button("Submit");
		submitButton.setLayoutX(250.0);
		submitButton.setLayoutY(200.0);
		submitButton.setPrefHeight(37.0);
		submitButton.setPrefWidth(100.0);
		submitButton.setStyle("-fx-background-color: #2196f3;");
		submitButton.setFont(new Font(18.0));

		Button backButton = new Button("Back");
		backButton.setLayoutX(20.0);
		backButton.setLayoutY(20.0);
		backButton.setPrefHeight(37.0);
		backButton.setPrefWidth(80.0);
		backButton.setStyle("-fx-background-color: #ff6347;");
		backButton.setFont(new Font(18.0));
		backButton.setOnAction(event -> showLoginPage(primaryStage));

		
		
		
		submitButton.setOnAction(event ->{
			String oldPassword = oldPasswordField.getText().trim();
			String newPassword = newPasswordField.getText().trim();

	       if (oldPassword.isEmpty() || newPassword.isEmpty()) {
	           showAlert("Please fill in all fields.");
	            return;
	        }

	        try {
	            if (checkValidUser(username, oldPassword)) {
	                connectDB();
	                String sql = "UPDATE user SET upassword = ? WHERE uname = ?";
	                PreparedStatement pstmt = con.prepareStatement(sql);
	                pstmt.setString(1, newPassword);
	                pstmt.setString(2, username);
	                pstmt.executeUpdate();
	                pstmt.close();
	                con.close();
	                showAlert("Password reset successfully.");
	            } else {
	                showAlert("Invalid old password.");
	            }
	        } catch (ClassNotFoundException | SQLException e) {
	            e.printStackTrace();
	            showAlert("An error occurred while resetting the password.");
	        }
		});

		forgetPasswordRoot.getChildren().addAll(oldPasswordField, newPasswordField, submitButton, backButton);
		
		Scene forgetPasswordScene = new Scene(forgetPasswordRoot);
		primaryStage.setScene(forgetPasswordScene);
		primaryStage.setTitle("Reset Password");
	}
	
	
	
	@SuppressWarnings("unchecked")
	public void showSuperMarketManagement(Stage primaryStage) throws ClassNotFoundException, SQLException {
		
		itemData = new ArrayList<>();
		getItemData();		
		
		//convert data from arraylist to observable arraylist
	    itemDataList = FXCollections.observableArrayList(itemData);
	    
	    tableView.setLayoutX(14.0);
		tableView.setLayoutY(14.0);
		tableView.setPrefHeight(250.0);
		tableView.setPrefWidth(650);
		tableView.setEditable(true);
		
		
		
		TableColumn<Item,String> itemStatusColumn = new TableColumn<Item,String>("Product Status");
		itemStatusColumn.setPrefWidth(115.0);
		itemStatusColumn.setCellValueFactory(new PropertyValueFactory<Item, String>("itemStatus"));
		itemStatusColumn.setCellFactory(TextFieldTableCell.<Item>forTableColumn());


		itemStatusColumn.setOnEditCommit(
        		(CellEditEvent<Item, String> t) -> {
                       ((Item) t.getTableView().getItems().get(
        	                        t.getTablePosition().getRow())
        	                        ).setItemStatus(t.getNewValue()); //display only
                       updateitemStatuscolumn( t.getRowValue().getItem_id(),t.getNewValue());
        		});
		

		
		TableColumn<Item,Integer> productIdColumn = new TableColumn<Item,Integer>("Product ID");
		productIdColumn.setPrefWidth(75.0);
		productIdColumn.setCellValueFactory(
        		new PropertyValueFactory<Item, Integer>("Item_id"));
		
		
		TableColumn<Item,String> productNameColumn = new TableColumn<Item,String>("Product Name");
		productNameColumn.setPrefWidth(115.0);
		productNameColumn.setCellValueFactory(new PropertyValueFactory<Item, String>("iname"));
		productNameColumn.setCellFactory(TextFieldTableCell.<Item>forTableColumn());


		productNameColumn.setOnEditCommit(
        		(CellEditEvent<Item, String> t) -> {
                       ((Item) t.getTableView().getItems().get(
        	                        t.getTablePosition().getRow())
        	                        ).setIname(t.getNewValue()); //display only
                       updateIname( t.getRowValue().getItem_id(),t.getNewValue());
        		});

		TableColumn<Item,String> typeColumn = new TableColumn<Item,String>("Item Type");
		typeColumn.setPrefWidth(115.0);
		typeColumn.setCellValueFactory(new PropertyValueFactory<Item, String>("category"));
		typeColumn.setCellFactory(TextFieldTableCell.<Item>forTableColumn());


		typeColumn.setOnEditCommit(
        		(CellEditEvent<Item, String> t) -> {
                       ((Item) t.getTableView().getItems().get(
        	                        t.getTablePosition().getRow())
        	                        ).setCategory(t.getNewValue()); //display only
                       updatetypeColumn( t.getRowValue().getItem_id(),t.getNewValue());
        		});
		
		
		TableColumn<Item, Integer> quantityColumn = new TableColumn<>("Stock");
		quantityColumn.setPrefWidth(115.0);
		// Set the cell value factory to the 'price' property of the Item class
		quantityColumn.setCellValueFactory(new PropertyValueFactory<Item, Integer>("quantity"));       
	             	       
		quantityColumn.setCellFactory(TextFieldTableCell.<Item,Integer>
        		forTableColumn(new IntegerStringConverter()));
				
		quantityColumn.setOnEditCommit(
        		(CellEditEvent<Item, Integer> t) -> {
                       ((Item) t.getTableView().getItems().get(
        	                        t.getTablePosition().getRow())
        	                        ).setQuantity(t.getNewValue()); //display only
                       updatequantityColumn( t.getRowValue().getItem_id(),t.getNewValue());
        		});
		
	
		TableColumn<Item, Double> priceColumn = new TableColumn<Item, Double>("Price");
		priceColumn.setMinWidth(115.0);
		priceColumn.setCellValueFactory(new PropertyValueFactory<Item, Double>("price"));

		// Use DoubleStringConverter for the price column
		priceColumn.setCellFactory(TextFieldTableCell.<Item, Double>forTableColumn(new DoubleStringConverter()));

		priceColumn.setOnEditCommit(
		    (CellEditEvent<Item, Double> t) -> {
		        ((Item) t.getTableView().getItems().get(
		            t.getTablePosition().getRow())
		        ).setPrice(t.getNewValue());
		        updatepriceColumn(t.getRowValue().getItem_id(), t.getNewValue());
		    }
		);

		
		
		tableView.setItems(itemDataList);
	        
		tableView.getColumns().addAll(productIdColumn, productNameColumn, typeColumn,priceColumn,quantityColumn, itemStatusColumn);

		AnchorPane anchorPane = new AnchorPane();
		anchorPane.setPrefHeight(1.0);
		anchorPane.setPrefWidth(6.0);

		BorderPane borderPane = new BorderPane();
		borderPane.setPrefHeight(538.0);
		borderPane.setPrefWidth(981.0);
		AnchorPane.setBottomAnchor(borderPane, 0.0);
		AnchorPane.setLeftAnchor(borderPane, 0.0);
		AnchorPane.setRightAnchor(borderPane, 0.0);
		AnchorPane.setTopAnchor(borderPane, 0.0);

		// Left Pane
		AnchorPane leftPane = new AnchorPane();
		leftPane.setPrefHeight(538.0);
		leftPane.setPrefWidth(259.0);
		leftPane.setStyle("-fx-background-color: #246861;");

		AnchorPane topPane = new AnchorPane();
		topPane.setLayoutX(-2.0);
		topPane.setPrefHeight(101.0);
		topPane.setPrefWidth(262.0);
		topPane.setStyle("-fx-background-color: #098c53;");

		Label titleLabel = new Label("SuperMarket Management");
		titleLabel.setAlignment(javafx.geometry.Pos.TOP_CENTER);
		titleLabel.setLayoutX(48.0);
		titleLabel.setLayoutY(27.0);
		titleLabel.setFont(Font.font("System Bold Italic", 15.0));

		topPane.getChildren().add(titleLabel);

		Button dashboardButton = new Button("DASHBOARD");
		dashboardButton.setLayoutX(16.0);
		dashboardButton.setLayoutY(219.0);
		dashboardButton.setMnemonicParsing(false);
		dashboardButton.setPrefHeight(41.0);
		dashboardButton.setPrefWidth(227.0);
		dashboardButton.setStyle("-fx-background-color: #246861;");
		dashboardButton.setTextFill(javafx.scene.paint.Color.WHITE);
		dashboardButton.setFont(Font.font("System Bold", 13.0));
		dashboardButton.setOnAction(event -> showDashboardPage(primaryStage));

		Button inventoryButton = new Button("INVENTORY");
		inventoryButton.setLayoutX(17.0);
		inventoryButton.setLayoutY(260.0);
		inventoryButton.setMnemonicParsing(false);
		inventoryButton.setPrefHeight(41.0);
		inventoryButton.setPrefWidth(227.0);
		inventoryButton.setStyle("-fx-background-color: #246861;");
		inventoryButton.setTextFill(javafx.scene.paint.Color.WHITE);
		inventoryButton.setFont(Font.font("System Bold", 13.0));

		Button menuButton = new Button("MENU");
		menuButton.setLayoutX(17.0);
		menuButton.setLayoutY(301.0);
		menuButton.setMnemonicParsing(false);
		menuButton.setPrefHeight(41.0);
		menuButton.setPrefWidth(227.0);
		menuButton.setStyle("-fx-background-color: #246861;");
		menuButton.setTextFill(javafx.scene.paint.Color.WHITE);
		menuButton.setFont(Font.font("System Bold", 13.0));

		Button customersButton = new Button("CUSTOMERS");
		customersButton.setLayoutX(16.0);
		customersButton.setLayoutY(345.0);
		customersButton.setMnemonicParsing(false);
		customersButton.setPrefHeight(41.0);
		customersButton.setPrefWidth(227.0);
		customersButton.setStyle("-fx-background-color: #246861;");
		customersButton.setTextFill(javafx.scene.paint.Color.WHITE);
		customersButton.setFont(Font.font("System Bold", 13.0));
		customersButton.setOnAction(event -> showCustomerPage(primaryStage));

		Button signOutButton = new Button("SIGN OUT");
		signOutButton.setLayoutX(43.0);
		signOutButton.setLayoutY(541.0);
		signOutButton.setMnemonicParsing(false);
		signOutButton.setPrefHeight(31.0);
		signOutButton.setPrefWidth(86.0);
		signOutButton.setStyle("-fx-background-color: #246861;");
		signOutButton.setTextFill(javafx.scene.paint.Color.WHITE);
		signOutButton.setFont(Font.font("System Bold", 13.0));
		signOutButton.setOnAction(event -> showLoginPage(primaryStage));

		leftPane.getChildren().addAll(topPane, dashboardButton, inventoryButton, menuButton, customersButton,
				signOutButton);

		borderPane.setLeft(leftPane);

		// Center Pane
		AnchorPane centerPane = new AnchorPane();
		centerPane.setPrefHeight(601.0);
		centerPane.setPrefWidth(817.0);

		AnchorPane tablePane = new AnchorPane();
		tablePane.setLayoutX(5.0);
		tablePane.setLayoutY(6.0);
		tablePane.setPrefHeight(211.0);
		tablePane.setPrefWidth(709.0);
		tablePane.getStyleClass().add("white.bg");

		
		tablePane.getChildren().add(tableView);

		AnchorPane formPane = new AnchorPane();
		formPane.setLayoutX(14.0);
		formPane.setLayoutY(308.0);
		formPane.setPrefHeight(282.0);
		formPane.setPrefWidth(788.0);

		Label productIdLabel = new Label("Product ID:");
		productIdLabel.setLayoutX(27.0);
		productIdLabel.setLayoutY(27.0);
		productIdLabel.setPrefHeight(26.0);
		productIdLabel.setPrefWidth(64.0);
		productIdLabel.setFont(Font.font("System Bold", 12.0));

		Label productNameLabel = new Label("Product Name:");
		productNameLabel.setLayoutX(13.0);
		productNameLabel.setLayoutY(74.0);
		productNameLabel.setPrefHeight(26.0);
		productNameLabel.setPrefWidth(92.0);
		productNameLabel.setFont(Font.font("System Bold", 12.0));

		TextField productIdField = new TextField();
		productIdField.setLayoutX(115.0);
		productIdField.setLayoutY(25.0);
		productIdField.setPrefHeight(31.0);
		productIdField.setPrefWidth(118.0);
		TextField productNameField = new TextField();
		productNameField.setLayoutX(115.0);
		productNameField.setLayoutY(72.0);
		productNameField.setPrefHeight(31.0);
		productNameField.setPrefWidth(181.0);

		Label typeLabel = new Label("Type:");
		typeLabel.setLayoutX(33.0);
		typeLabel.setLayoutY(122.0);
		typeLabel.setPrefHeight(26.0);
		typeLabel.setPrefWidth(44.0);
		typeLabel.setFont(Font.font("System Bold", 12.0));

		TextField stockField = new TextField();
		stockField.setLayoutX(413.0);
		stockField.setLayoutY(25.0);
		stockField.setPrefHeight(31.0);
		stockField.setPrefWidth(181.0);
		stockField.setPromptText("0");

		ComboBox<String> typeComboBox = new ComboBox<>(FXCollections.observableArrayList("meat", "candy","chips","fruits & vegetables"));
		typeComboBox.setLayoutX(115.0);
		typeComboBox.setLayoutY(123.0);
		typeComboBox.setPrefHeight(31.0);
		typeComboBox.setPrefWidth(179.0);
		typeComboBox.setPromptText("Choose Type...");

		Label stockLabel = new Label("Stock:");
		stockLabel.setLayoutX(340.0);
		stockLabel.setLayoutY(28.0);
		stockLabel.setPrefHeight(26.0);
		stockLabel.setPrefWidth(64.0);
		stockLabel.setFont(Font.font("System Bold", 12.0));

		Label priceLabel = new Label("Price:");
		priceLabel.setLayoutX(340.0);
		priceLabel.setLayoutY(75.0);
		priceLabel.setPrefHeight(26.0);
		priceLabel.setPrefWidth(64.0);
		priceLabel.setFont(Font.font("System Bold", 12.0));

		TextField priceField = new TextField();
		priceField.setLayoutX(413.0);
		priceField.setLayoutY(72.0);
		priceField.setPrefHeight(31.0);
		priceField.setPrefWidth(181.0);
		priceField.setPromptText("$0.0");

		Button addButton = new Button("ADD");
		addButton.setLayoutX(53.0);
		addButton.setLayoutY(214.0);
		addButton.setMnemonicParsing(false);
		addButton.setPrefHeight(49.0);
		addButton.setPrefWidth(125.0);
		addButton.setFont(Font.font("System Bold", 13.0));

		Button updateButton = new Button("UPDATE");
		updateButton.setLayoutX(225.0);
		updateButton.setLayoutY(214.0);
		updateButton.setMnemonicParsing(false);
		updateButton.setPrefHeight(49.0);
		updateButton.setPrefWidth(125.0);
		updateButton.setFont(Font.font("System Bold", 13.0));

		Button clearButton = new Button("CLEAR");
		clearButton.setLayoutX(404.0);
		clearButton.setLayoutY(214.0);
		clearButton.setMnemonicParsing(false);
		clearButton.setPrefHeight(49.0);
		clearButton.setPrefWidth(125.0);
		clearButton.setFont(Font.font("System Bold", 13.0));

		Button deleteButton = new Button("DELETE");
		deleteButton.setLayoutX(580.0);
		deleteButton.setLayoutY(214.0);
		deleteButton.setMnemonicParsing(false);
		deleteButton.setPrefHeight(49.0);
		deleteButton.setPrefWidth(125.0);
		deleteButton.setFont(Font.font("System Bold", 13.0));

		Label statusLabel = new Label("Status:");
		statusLabel.setLayoutX(340.0);
		statusLabel.setLayoutY(128.0);
		statusLabel.setPrefHeight(26.0);
		statusLabel.setPrefWidth(44.0);
		statusLabel.setFont(Font.font("System Bold", 12.0));

		ComboBox<String> statusComboBox = new ComboBox<>(FXCollections.observableArrayList("Available", "unavailable"));
		statusComboBox.setLayoutX(414.0);
		statusComboBox.setLayoutY(126.0);
		statusComboBox.setPrefHeight(31.0);
		statusComboBox.setPrefWidth(179.0);
		statusComboBox.setPromptText("Choose Status...");
		
		
		
		//tableView.setItems(dataList);
		
		addButton.setOnAction(event -> {
		    boolean fieldsFilled = true;
		    String errorMessage = "Please fill out all fields.";

		    int productId = 0;
		    String productName = productNameField.getText();
		    int productStock = 0;
		    double productPrice = 0.0;
		    String productType = typeComboBox.getValue();
		    String productStatus = statusComboBox.getValue();

		    if (productName.isEmpty() || productType == null || productStatus == null) {
		        fieldsFilled = false;
		    }

		    try {
		        productId = Integer.parseInt(productIdField.getText());
		        productStock = Integer.parseInt(stockField.getText());
		        productPrice = Double.parseDouble(priceField.getText());
		    } catch (NumberFormatException e) {
		        fieldsFilled = false;
		        errorMessage = "Please enter valid numbers for ID, stock, and price.";
		    }

		    if (fieldsFilled) {
		        try {
		        	 connectDB();
		             ExecuteStatement("Insert into item (item_id, iname, price, category,quantity,itemStatus) values("
		                     + productId + ",'"
		                     + productName + "',"
		                     + productPrice + ",'"
		                     + productType + "',"
		                     + productStock+ ",'"
		                     + productStatus +"');"
		                     );
		            
		            // Assuming 'dataList' is the ObservableList that backs your TableView
		            Item newItem = new Item(
		                    productId,
		                    productName,
		                    productType,
		                    productPrice,
		                    "URL", 
		                    1 ,
		                    productStock,
		                    productStatus
		            );
		           
		            itemDataList.add(newItem);
		            
		        //    tableView.refresh(); // Refresh the TableView to show the new data

		            showAlert("Item saved successfully");
		            productIdField.clear();
			    	productNameField.clear();
			    	stockField.clear();
			    	priceField.clear();
			    	typeComboBox.getSelectionModel().clearSelection();
			    	statusComboBox.getSelectionModel().clearSelection();
			    	statusComboBox.setPromptText("Choose Status...");
			    	typeComboBox.setPromptText("Choose Type...");

		            
		        } catch (ClassNotFoundException | SQLException e) {
		            e.printStackTrace();
		            showAlert("An error occurred while saving the item.");
		        }
		    } else {
		        showAlert(errorMessage);
		    }
		});

		
		
		deleteButton.setOnAction(event -> {
			ObservableList<Item> selectedRows = tableView.getSelectionModel().getSelectedItems();
        	ArrayList<Item> rows = new ArrayList<>(selectedRows);
        	rows.forEach(row -> {
        		tableView.getItems().remove(row); 
        		try {
        			connectDB();
        			ExecuteStatement("delete from  Item where item_id="+row.getItem_id() + ";");
        			con.close();
        			
        			} catch (SQLException e) {
        				e.printStackTrace();
        			} catch (ClassNotFoundException e) {
        				e.printStackTrace();
        			} 
        		
        		tableView.refresh();
        		});
        	
		});

		
		
		clearButton.setOnAction(event -> {	 
	    	
		});

		
		
		formPane.getChildren().addAll(productIdLabel, productNameLabel, productIdField, productNameField, typeLabel,
				stockField, typeComboBox, stockLabel, priceLabel, priceField, addButton, updateButton, clearButton,
				deleteButton, statusLabel, statusComboBox);

		centerPane.getChildren().addAll(tablePane, formPane);
		borderPane.setCenter(centerPane);

		anchorPane.getChildren().add(borderPane);

		Scene scene = new Scene(anchorPane, 981, 538);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Supermarket Management");
		primaryStage.show();
	}
	
	
	
	@SuppressWarnings({ "unchecked" })
	private void showItemTableView() throws ClassNotFoundException, SQLException {
		
				
	}
	
	
	
	public void updatequantityColumn(int item_id, int quantity) {
		
		try {
			System.out.println("update  item set quantity = "+quantity + " where item_id = "+item_id);
			connectDB();
			ExecuteStatement("update  item set quantity = "+quantity + " where item_id = "+item_id+";");
			con.close();
			System.out.println("Connection closed.");
			
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
	}
		
	
public void updateitemStatuscolumn(int item_id, String itemStatus) {
		
		try {
			System.out.println("update  item set itemStatus = '"+itemStatus + "' where item_id = "+item_id);
			connectDB();
			ExecuteStatement("update  item set itemStatus = '"+itemStatus + "' where item_id = "+item_id+";");
			con.close();
			System.out.println("Connection closed.");
			
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
	}
	
public void updateIname(int Item_id, String iname) {
		
		try {
			System.out.println("update  Item set iname = '"+iname + "' where Item_id = "+Item_id);
			connectDB();
			ExecuteStatement("update  Item set iname = '"+iname + "' where Item_id = "+Item_id+";");
			con.close();
			System.out.println("Connection closed.");
			
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
	}
	
	
public void updatepriceColumn(int Item_id, Double double1) {
	
	try {
		System.out.println("update  Item set price = "+double1 + " where Item_id = "+Item_id);
		connectDB();
		ExecuteStatement("update  Item set price = "+double1 + " where Item_id = "+Item_id+";");
		con.close();
		System.out.println("Connection closed.");
		
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
}


public void updatetypeColumn(int Item_id, String category) {
		
		try {
			System.out.println("update  Item set category = '"+category + "' where Item_id = "+Item_id);
			connectDB();
			ExecuteStatement("update  Item set category = '"+category + "' where Item_id = "+Item_id+";");
			con.close();
			System.out.println("Connection closed.");
			
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
	}
	
	
	@SuppressWarnings("unchecked")
	private void showUserScreen(Stage primaryStage, String username) throws ClassNotFoundException, SQLException {
		
		itemData = new ArrayList<>();
		getItemData();		
		
		//convert data from arraylist to observable arraylist
	    itemDataList = FXCollections.observableArrayList(itemData);
	    
	    tableView.setLayoutX(14.0);
		tableView.setLayoutY(14.0);
		tableView.setPrefHeight(250.0);
		tableView.setPrefWidth(535);
		
		tableView.setEditable(true);
		
		
		       
	             	       
		
		
		TableColumn<Item, Double> priceColumn = new TableColumn<Item, Double>("Price");
		priceColumn.setMinWidth(115.0);
		priceColumn.setCellValueFactory(new PropertyValueFactory<Item, Double>("price"));

		// Use DoubleStringConverter for the price column
		
		
		
		TableColumn<Item,String> itemStatusColumn = new TableColumn<Item,String>("Product Status");
		itemStatusColumn.setPrefWidth(115.0);
		itemStatusColumn.setCellValueFactory(new PropertyValueFactory<Item, String>("itemStatus"));
		
		

		
		TableColumn<Item,Integer> productIdColumn = new TableColumn<Item,Integer>("Product ID");
		productIdColumn.setPrefWidth(75.0);
		productIdColumn.setCellValueFactory(
        		new PropertyValueFactory<Item, Integer>("Item_id"));
		
		
		TableColumn<Item,String> productNameColumn = new TableColumn<Item,String>("Product Name");
		productNameColumn.setPrefWidth(115.0);
		productNameColumn.setCellValueFactory(new PropertyValueFactory<Item, String>("iname"));
		
		

		TableColumn<Item,String> typeColumn = new TableColumn<Item,String>("Item Type");
		typeColumn.setPrefWidth(115.0);
		typeColumn.setCellValueFactory(new PropertyValueFactory<Item, String>("category"));
		

		tableView.setItems(itemDataList);
	        
		tableView.getColumns().addAll(productIdColumn, productNameColumn, priceColumn, typeColumn, itemStatusColumn);
		
		BorderPane root = new BorderPane();
		root.setPrefSize(1077, 566);

		// Left Pane
		AnchorPane leftPane = new AnchorPane();
		leftPane.setPrefSize(259, 538);
		leftPane.setStyle("-fx-background-color: #246861;");

		AnchorPane topPane = new AnchorPane();
		topPane.setPrefSize(262, 101);
		topPane.setStyle("-fx-background-color: #098c53;");

		Label titleLabel = new Label("SuperMarket Management");
		titleLabel.setAlignment(Pos.TOP_CENTER);
		titleLabel.setLayoutX(48);
		titleLabel.setLayoutY(27);
		titleLabel.setFont(Font.font("System Bold Italic", 15));

		topPane.getChildren().add(titleLabel);

		Button inventoryButton = new Button("INVENTORY");
		inventoryButton.setLayoutX(17);
		inventoryButton.setLayoutY(260);
		inventoryButton.setPrefSize(227, 41);
		inventoryButton.setStyle("-fx-background-color: #246861;");
		inventoryButton.setTextFill(javafx.scene.paint.Color.WHITE);
		inventoryButton.setFont(Font.font("System Bold", 13));
		inventoryButton.setOnAction(event -> {
			try {
				showCustomerCart(primaryStage,username);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		Button menuButton = new Button("MENU");
		menuButton.setLayoutX(17);
		menuButton.setLayoutY(301);
		menuButton.setPrefSize(227, 41);
		menuButton.setStyle("-fx-background-color: #246861;");
		menuButton.setTextFill(javafx.scene.paint.Color.WHITE);
		menuButton.setFont(Font.font("System Bold", 13));

		Button signOutButton = new Button("SIGN OUT");
		signOutButton.setLayoutX(43);
		signOutButton.setLayoutY(541);
		signOutButton.setPrefSize(86, 31);
		signOutButton.setStyle("-fx-background-color: #246861;");
		signOutButton.setTextFill(javafx.scene.paint.Color.WHITE);
		signOutButton.setFont(Font.font("System Bold", 13));
		signOutButton.setOnAction(event -> showLoginPage(primaryStage));

		leftPane.getChildren().addAll(topPane, inventoryButton, menuButton, signOutButton);

		root.setLeft(leftPane);

		// Center Pane
		AnchorPane centerPane = new AnchorPane();
		centerPane.setPrefSize(817, 601);

		AnchorPane tablePane = new AnchorPane();
		tablePane.setLayoutX(5);
		tablePane.setLayoutY(6);
		tablePane.setPrefSize(709, 211);
		tablePane.getStyleClass().add("white.bg");


		tablePane.getChildren().add(tableView);

		AnchorPane formPane = new AnchorPane();
		formPane.setLayoutX(109);
		formPane.setLayoutY(391);
		formPane.setPrefSize(538, 137);

		Button addButton = new Button("ADD");
		addButton.setLayoutX(123);
		addButton.setLayoutY(77);
		addButton.setPrefSize(125, 49);
		addButton.setFont(Font.font("System Bold", 13));
		
		addButton.setOnAction(event -> {

		    ObservableList<Item> selectedRows = tableView.getSelectionModel().getSelectedItems();
		    ArrayList<Item> rows = new ArrayList<>(selectedRows);
		    rows.forEach(row -> {
		        int Item_id = row.getItem_id();
		        
		        // Assuming 'username' is a valid String variable obtained from the user context
		        Integer user_id = null;
		        String sql = "SELECT user_id FROM user WHERE uname = ?";
		        try {
		            connectDB(); // Ensure this method sets up the 'con' variable correctly
		            PreparedStatement pstmt = con.prepareStatement(sql);
		            pstmt.setString(1, username);
		            ResultSet rs = pstmt.executeQuery();
		            
		            if (rs.next()) {
		                user_id = rs.getInt("user_id");
		            }
		            
		            // Assuming 'addItemToCart' is a method that adds the item to the cart
		            addItemToCart(user_id, Item_id, 1);
		            showAlert("Product added successfully.");
		            
		        } catch (ClassNotFoundException | SQLException e) {
		            e.printStackTrace();
		            // Implement proper error handling, such as showing an error alert
		            showAlert("Failed to add product to cart.");
		        }
		    });
		});

			
		
			
		//	Product selectedProduct = tableView.getSelectionModel().getSelectedItem();
		//	if (selectedProduct != null) {
		//		showRegisterPageproduct(primaryStage, selectedProduct);
		//	} else {
		//	showRegisterPage(primaryStage, null);
		//	}
		

		formPane.getChildren().add(addButton);

		centerPane.getChildren().addAll(tablePane, formPane);
		root.setCenter(centerPane);

		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.setTitle("SuperMarket Management");
		primaryStage.show();
	}
	
	
	@SuppressWarnings("unchecked")
	private void showCustomerCart(Stage primaryStage,String username) throws ClassNotFoundException, SQLException {
		
		int userId = getUserIdByUsername(username);

	        itemData = new ArrayList<>();
	        getItemsForUserCart(userId);
	        itemDataList = FXCollections.observableArrayList(itemData);
	        
			
			
			//convert data from arraylist to observable arraylist
		    
		    tableView.setLayoutX(14.0);
			tableView.setLayoutY(14.0);
			tableView.setPrefHeight(250.0);
			tableView.setPrefWidth(535);
	    
		
		BorderPane root = new BorderPane();
		root.setPrefSize(1077, 566);

		// Top Pane with Back Button
		HBox topPane = new HBox();
		topPane.setSpacing(10);
		topPane.setAlignment(Pos.CENTER_LEFT);
		topPane.setStyle("-fx-padding: 10;");

		Button backButton = new Button("Back");
		backButton.setOnAction(event -> {
			try {
				showUserScreen(primaryStage,username);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		topPane.getChildren().add(backButton);
		tableView.setItems(itemDataList);
		root.setTop(topPane);
		
		root.setCenter(tableView);

		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Customer Cart");
		primaryStage.show();
	}
	
	
	private Integer getUserIdByUsername(String username) throws SQLException, ClassNotFoundException {
		Integer user_id = null;
        String sql = "SELECT user_id FROM user WHERE uname = ?";
        
            connectDB(); // Ensure this method sets up the 'con' variable correctly
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                user_id = rs.getInt("user_id");
            }
	    
	    return user_id;
	    
		
	}
        
	
	private void getItemsForUserCart(int userId) throws SQLException, ClassNotFoundException {
		
	    String sql = "SELECT i.item_id, i.iname, i.category, i.price, i.imageURL, i.warehouse_id, a.quantity, i.itemStatus " +
                "FROM cart c " +
                "JOIN additemtocart a ON c.cart_id = a.cart_id " +
                "JOIN item i ON a.item_id = i.item_id " +
                "WHERE c.user_id = ?";
	    connectDB();
	         PreparedStatement pstmt = con.prepareStatement(sql);
	        
	        pstmt.setInt(1, userId);
	        ResultSet rs = pstmt.executeQuery();
	        
	        while (rs.next()) {  
	            Item item = new Item(rs.getInt("item_id"), rs.getString("iname"), rs.getString("category"), rs.getDouble("price"), rs.getString("imageURL"),rs.getInt("warehouse_id"), rs.getInt("quantity"),  rs.getString("itemStatus"));
	            itemData.add(item);
	        }
	}


	
	
	public void addItemToCart(int userId, int itemId, int quantity) throws ClassNotFoundException, SQLException {
	    // Check if the cart exists for the user, if not create one
	    int cartId = getOrCreateCart(userId);
	
	    // Check if the product is already in the cart
	    int currentQuantity = checkItemInCart(cartId, itemId);

	    if (currentQuantity > 0) {
	        // If the product is already in the cart, update the quantity
	        updateCartItem(cartId, itemId, currentQuantity + quantity);
	    } else {
	        // If the product is not in the cart, add it
	        insertCartItem(cartId, itemId, quantity);
	    }
	}
	
	
	public int getOrCreateCart(int user_Id) {
	    // Check if the user already has a cart
	    String checkCartQuery = "SELECT cart_id FROM Cart WHERE user_id = ?";
	   try {
		connectDB();
	 
	         PreparedStatement checkStmt = con.prepareStatement(checkCartQuery); 
	        
	        checkStmt.setInt(1, user_Id);
	        ResultSet rs = checkStmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getInt("cart_id");
	        } else {
	            // If not, create a new cart and return its ID
	            String insertCartQuery = "INSERT INTO Cart (user_id) VALUES (?)";
	            try (PreparedStatement insertStmt = con.prepareStatement(insertCartQuery, Statement.RETURN_GENERATED_KEYS)) {
	                insertStmt.setInt(1, user_Id);
	                insertStmt.executeUpdate();
	                
	                ResultSet generatedKeys = insertStmt.getGeneratedKeys();
	                if (generatedKeys.next()) {
	                    return generatedKeys.getInt(1);
	                } else {
	                    throw new SQLException("Creating cart failed, no ID obtained.");
	                }
	            }
	        }
	} catch (ClassNotFoundException | SQLException e) {
	    		// TODO Auto-generated catch block
	    		e.printStackTrace();
	    	}
	    return -1; // Return an invalid value in case of failure
	}
	
	
	public int checkItemInCart(int cartId, int productId) throws ClassNotFoundException {
	    String query = "SELECT quantity FROM additemtocart WHERE cart_id = ? AND item_id = ?";
	    try {
	    	connectDB();
	         PreparedStatement stmt = con.prepareStatement(query); 
	        
	        stmt.setInt(1, cartId);
	        stmt.setInt(2, productId);
	        ResultSet rs = stmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getInt("quantity");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // Handle exception properly
	    }
	    return 0; // Return 0 if the product is not in the cart
	}

		
	public void updateCartItem(int cartId, int productId, int newQuantity) throws ClassNotFoundException, SQLException {
	    String query = "UPDATE additemtocart SET quantity = ? WHERE cart_id = ? AND item_id = ?";
	    connectDB();
	    PreparedStatement stmt = con.prepareStatement(query);
	        
	        stmt.setInt(1, newQuantity);
	        stmt.setInt(2, cartId);
	        stmt.setInt(3, productId);
	        stmt.executeUpdate();
	    
	}
	
	
	public void insertCartItem(int cartId, int productId, int quantity) throws ClassNotFoundException, SQLException {
	    String query = "INSERT INTO additemtocart (cart_id, item_id, quantity) VALUES (?, ?, ?)";
	    connectDB();	         
	    PreparedStatement stmt = con.prepareStatement(query) ;
	        
	        stmt.setInt(1, cartId);
	        stmt.setInt(2, productId);
	        stmt.setInt(3, quantity);
	        stmt.executeUpdate();
	   
	}
	
	
	
	private void showDashboardPage(Stage primaryStage) {
		BorderPane dashboardPane = new BorderPane();

		VBox chartPane = new VBox();
		chartPane.setSpacing(10);

		CategoryAxis xAxis = new CategoryAxis();
		xAxis.setLabel("Category");

		NumberAxis yAxis = new NumberAxis();
		yAxis.setLabel("Value");

		BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
		barChart.setTitle("Sample Bar Chart");

		XYChart.Series<String, Number> dataSeries = new XYChart.Series<>();
		dataSeries.setName("2024");
		dataSeries.getData().add(new XYChart.Data<>("Jan", 200));
		dataSeries.getData().add(new XYChart.Data<>("Feb", 300));
		dataSeries.getData().add(new XYChart.Data<>("Mar", 150));

		barChart.getData().add(dataSeries);

		chartPane.getChildren().add(barChart);

		Button backButton = new Button("Back");
		backButton.setOnAction(event -> {
			try {
				showSuperMarketManagement(primaryStage);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		dashboardPane.setTop(backButton);
		dashboardPane.setCenter(chartPane);

		Scene dashboardScene = new Scene(dashboardPane, 981, 538);
		primaryStage.setScene(dashboardScene);
		primaryStage.setTitle("Dashboard");
	}

	public void showCustomerPage(Stage primaryStage) {
		AnchorPane root = new AnchorPane();
		root.setPrefHeight(593.0);
		root.setPrefWidth(957.0);

		BorderPane borderPane = new BorderPane();
		borderPane.setPrefHeight(533.0);
		borderPane.setPrefWidth(964.0);
		AnchorPane.setBottomAnchor(borderPane, 0.0);
		AnchorPane.setLeftAnchor(borderPane, 0.0);
		AnchorPane.setRightAnchor(borderPane, 0.0);
		AnchorPane.setTopAnchor(borderPane, 0.0);

		// Top AnchorPane containing TableView
		AnchorPane topPane = new AnchorPane();
		topPane.setPrefHeight(443.0);
		topPane.setPrefWidth(1042.0);

		tableViewcustomer = new TableView<>();
		tableViewcustomer.setLayoutX(6.0);
		tableViewcustomer.setLayoutY(14.0);
		tableViewcustomer.setPrefHeight(429.0);
		tableViewcustomer.setPrefWidth(940.0);

		TableColumn<Customer, Integer> idColumn = new TableColumn<>("ID");
		TableColumn<Customer, String> nameColumn = new TableColumn<>("Name");
		nameColumn.setPrefWidth(164.0);
		TableColumn<Customer, String> emailColumn = new TableColumn<>("Email");
		emailColumn.setPrefWidth(232.0);
		TableColumn<Customer, String> passwordColumn = new TableColumn<>("Password");
		passwordColumn.setPrefWidth(156.0);
		TableColumn<Customer, String> addressColumn = new TableColumn<>("Address");
		addressColumn.setPrefWidth(164.0);
		TableColumn<Customer, String> phoneNumberColumn = new TableColumn<>("Phone Number");
		TableColumn<Customer, Double> totalPaymentColumn = new TableColumn<>("Total Payment");
		totalPaymentColumn.setPrefWidth(141.0);

		tableViewcustomer.getColumns().addAll(idColumn, nameColumn, emailColumn, passwordColumn, addressColumn,
				phoneNumberColumn, totalPaymentColumn);

	//	customerData = FXCollections.observableArrayList();
		//tableViewcustomer.setItems(customerData);

		topPane.getChildren().add(tableViewcustomer);

		// Bottom AnchorPane containing Buttons
		AnchorPane bottomPane = new AnchorPane();
		bottomPane.setPrefHeight(150.0);
		bottomPane.setPrefWidth(1046.0);

		Button addButton = new Button("Add");
		addButton.setLayoutX(105.0);
		addButton.setLayoutY(48.0);
		addButton.setPrefHeight(69.0);
		addButton.setPrefWidth(185.0);
		addButton.setFont(Font.font("System Bold", 15.0));
		addButton.setOnAction(event -> showRegisterPage(primaryStage, null));

		Button updateButton = new Button("Update");
		updateButton.setLayoutX(305.0);
		updateButton.setLayoutY(48.0);
		updateButton.setPrefHeight(69.0);
		updateButton.setPrefWidth(185.0);
		updateButton.setFont(Font.font("System Bold", 15.0));
		updateButton.setOnAction(event -> {
			Customer selectedCustomer = tableViewcustomer.getSelectionModel().getSelectedItem();
			if (selectedCustomer != null) {
				showRegisterPage(primaryStage, selectedCustomer);
			}
		});

		Button deleteButton = new Button("Delete");
		deleteButton.setLayoutX(505.0);
		deleteButton.setLayoutY(48.0);
		deleteButton.setPrefHeight(69.0);
		deleteButton.setPrefWidth(185.0);
		deleteButton.setFont(Font.font("System Bold", 15.0));
		deleteButton.setOnAction(event -> {
			Customer selectedCustomer = tableViewcustomer.getSelectionModel().getSelectedItem();
			if (selectedCustomer != null) {
				customerData.remove(selectedCustomer);
			}
		});

		Button backButton = new Button("Back");
		backButton.setLayoutX(705.0);
		backButton.setLayoutY(48.0);
		backButton.setPrefHeight(69.0);
		backButton.setPrefWidth(185.0);
		backButton.setFont(Font.font("System Bold", 15.0));
		backButton.setOnAction(event -> {
			try {
				showSuperMarketManagement(primaryStage);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		bottomPane.getChildren().addAll(addButton, updateButton, deleteButton, backButton);

		borderPane.setTop(topPane);
		borderPane.setBottom(bottomPane);

		root.getChildren().add(borderPane);

		Scene scene = new Scene(root, 957, 593);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Customer Page");
		primaryStage.show();
	}
	
	private void customerTableView(Stage showCustomerPage){
		
	}	

	private void showRegisterPageproduct(Stage primaryStage, Product product) throws ClassNotFoundException {
		AnchorPane registerPane = new AnchorPane();
		registerPane.setPrefHeight(400.0);
		registerPane.setPrefWidth(400.0);

		Label idLabel = new Label("Product ID:");
		idLabel.setLayoutX(50.0);
		idLabel.setLayoutY(50.0);
		TextField idField = new TextField();
		idField.setLayoutX(150.0);
		idField.setLayoutY(50.0);
		idField.setPrefWidth(200.0);

		Label nameLabel = new Label("Product Name:");
		nameLabel.setLayoutX(50.0);
		nameLabel.setLayoutY(100.0);
		TextField nameField = new TextField();
		nameField.setLayoutX(150.0);
		nameField.setLayoutY(100.0);
		nameField.setPrefWidth(200.0);

		Label typeLabel = new Label("Type:");
		typeLabel.setLayoutX(50.0);
		typeLabel.setLayoutY(150.0);
		TextField typeField = new TextField();
		typeField.setLayoutX(150.0);
		typeField.setLayoutY(150.0);
		typeField.setPrefWidth(200.0);

		Label stockLabel = new Label("Stock:");
		stockLabel.setLayoutX(50.0);
		stockLabel.setLayoutY(200.0);
		TextField stockField = new TextField();
		stockField.setLayoutX(150.0);
		stockField.setLayoutY(200.0);
		stockField.setPrefWidth(200.0);

		Label priceLabel = new Label("Price:");
		priceLabel.setLayoutX(50.0);
		priceLabel.setLayoutY(250.0);
		TextField priceField = new TextField();
		priceField.setLayoutX(150.0);
		priceField.setLayoutY(250.0);
		priceField.setPrefWidth(200.0);

		Label dateLabel = new Label("Date:");
		dateLabel.setLayoutX(50.0);
		dateLabel.setLayoutY(300.0);
		TextField dateField = new TextField();
		dateField.setLayoutX(150.0);
		dateField.setLayoutY(300.0);
		dateField.setPrefWidth(200.0);

		Label statusLabel = new Label("Status:");
		statusLabel.setLayoutX(50.0);
		statusLabel.setLayoutY(350.0);
		TextField statusField = new TextField();
		statusField.setLayoutX(150.0);
		statusField.setLayoutY(350.0);
		statusField.setPrefWidth(200.0);

		Button saveButton = new Button("Save");
		saveButton.setLayoutX(150.0);
		saveButton.setLayoutY(400.0);
		saveButton.setPrefWidth(100.0);
		saveButton.setOnAction(event -> {
			if (product == null) {
				Product newProduct = new Product(Integer.parseInt(idField.getText()), nameField.getText(),
						typeField.getText(), Integer.parseInt(stockField.getText()),
						Double.parseDouble(priceField.getText()), dateField.getText(), statusField.getText());
				tableViewproduct.getItems().add(newProduct);
			} else {
				product.setId(Integer.parseInt(idField.getText()));
				product.setName(nameField.getText());
				product.setType(typeField.getText());
				product.setStock(Integer.parseInt(stockField.getText()));
				product.setPrice(Double.parseDouble(priceField.getText()));
				product.setDate(dateField.getText());
				product.setStatus(statusField.getText());
				tableViewcustomer.refresh();
			}
			primaryStage.setScene(new Scene(new AnchorPane(), 957, 593));
		});

		if (product != null) {
			idField.setText(String.valueOf(product.getId()));
			nameField.setText(product.getName());
			typeField.setText(product.getType());
			stockField.setText(String.valueOf(product.getStock()));
			priceField.setText(String.valueOf(product.getPrice()));
			dateField.setText(product.getDate());
			statusField.setText(product.getStatus());
		}

		registerPane.getChildren().addAll(idLabel, idField, nameLabel, nameField, typeLabel, typeField, stockLabel,
				stockField, priceLabel, priceField, dateLabel, dateField, statusLabel, statusField, saveButton);

		primaryStage.setScene(new Scene(registerPane, 400, 400));
	}
	
////////////////////	private void ItemTableView(Stage primaryStage) {
		
////////////////////	}

	
	
	
	public void showRegisterPage(Stage primaryStage, Customer customer) {
		AnchorPane registerPane = new AnchorPane();
		registerPane.setPrefHeight(400.0);
		registerPane.setPrefWidth(400.0);

		Label idLabel = new Label("ID:");
		idLabel.setLayoutX(50.0);
		idLabel.setLayoutY(50.0);
		TextField idField = new TextField();
		idField.setLayoutX(150.0);
		idField.setLayoutY(50.0);
		idField.setPrefWidth(200.0);

		Label nameLabel = new Label("Name:");
		nameLabel.setLayoutX(50.0);
		nameLabel.setLayoutY(100.0);
		TextField nameField = new TextField();
		nameField.setLayoutX(150.0);
		nameField.setLayoutY(100.0);
		nameField.setPrefWidth(200.0);

		Label emailLabel = new Label("Email:");
		emailLabel.setLayoutX(50.0);
		emailLabel.setLayoutY(150.0);
		TextField emailField = new TextField();
		emailField.setLayoutX(150.0);
		emailField.setLayoutY(150.0);
		emailField.setPrefWidth(200.0);

		Label passwordLabel = new Label("Password:");
		passwordLabel.setLayoutX(50.0);
		passwordLabel.setLayoutY(200.0);
		TextField passwordField = new TextField();
		passwordField.setLayoutX(150.0);
		passwordField.setLayoutY(200.0);
		passwordField.setPrefWidth(200.0);

		Label addressLabel = new Label("Address:");
		addressLabel.setLayoutX(50.0);
		addressLabel.setLayoutY(250.0);
		TextField addressField = new TextField();
		addressField.setLayoutX(150.0);
		addressField.setLayoutY(250.0);
		addressField.setPrefWidth(200.0);

		Label phoneLabel = new Label("Phone Number:");
		phoneLabel.setLayoutX(50.0);
		phoneLabel.setLayoutY(300.0);
		TextField phoneField = new TextField();
		phoneField.setLayoutX(150.0);
		phoneField.setLayoutY(300.0);
		phoneField.setPrefWidth(200.0);

		Button saveButton = new Button("Save");
		saveButton.setLayoutX(150.0);
		saveButton.setLayoutY(350.0);
		saveButton.setPrefWidth(200.0);
		saveButton.setOnAction(event -> {
			if (customer == null) {
				Customer newCustomer = new Customer(Integer.parseInt(idField.getText()), nameField.getText(),
					emailField.getText(), passwordField.getText(), addressField.getText(), phoneField.getText());
				customerData.add(newCustomer);
			} else {
				customer.setId(Integer.parseInt(idField.getText()));
				customer.setName(nameField.getText());
				customer.setEmail(emailField.getText());
				customer.setPassword(passwordField.getText());
				customer.setAddress(addressField.getText());
				customer.setPhoneNumber(phoneField.getText());
				tableViewcustomer.refresh();
			}
			primaryStage.setScene(new Scene(new AnchorPane(), 957, 593));
			showCustomerPage(primaryStage);
		});

		if (customer != null) {
			idField.setText(customer.getId().toString());
			nameField.setText(customer.getName());
			emailField.setText(customer.getEmail());
			passwordField.setText(customer.getPassword());
			addressField.setText(customer.getAddress());
			phoneField.setText(customer.getPhoneNumber());
		}

		registerPane.getChildren().addAll(idLabel, idField, nameLabel, nameField, emailLabel, emailField, passwordLabel,
				passwordField, addressLabel, addressField, phoneLabel, phoneField, saveButton);

		primaryStage.setScene(new Scene(registerPane, 400, 450));
		primaryStage.setTitle(customer == null ? "Register Customer" : "Update Customer");
	}

	private boolean authenticate(String username, String password) {
		
		return "admin".equals(username) && "password".equals(password);
	}

	private void saveCredentials(String username, String password) {
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		prefs.put("username", username);
		prefs.put("password", password);
	}

	private String[] loadCredentials() {
		Preferences prefs = Preferences.userNodeForPackage(getClass());
		String username = prefs.get("username", "");
		String password = prefs.get("password", "");
		return new String[] { username, password };
		
	}

	
private void connectDB() throws ClassNotFoundException, SQLException {
		
		dbURL = "jdbc:mysql://" + URL + ":" + port + "/" + dbName + "?verifyServerCertificate=false";
		Properties p = new Properties();
		p.setProperty("user", dbUsername);
		p.setProperty("password", dbPassword);
		p.setProperty("useSSL", "false");
		p.setProperty("autoReconnect", "true");
		Class.forName("com.mysql.jdbc.Driver");
	
		con = DriverManager.getConnection (dbURL, p);

	}




public void ExecuteStatement(String SQL) throws SQLException {

	try {
		Statement stmt = con.createStatement();
		stmt.executeUpdate(SQL);
		stmt.close();
	
	}
	catch(SQLException s) {
		s.printStackTrace();
		System.out.println("SQL statement is not executed!");
		  
	}
	
}


private boolean checkUsernameExists(String username) throws SQLException, ClassNotFoundException {
    String SQL = "SELECT * FROM user WHERE uname LIKE ?;";
    connectDB();
    try (
         PreparedStatement stmt = con.prepareStatement(SQL)) {
         
        stmt.setString(1, username);
        try (ResultSet rs = stmt.executeQuery()) {
            return rs.next();
        }
    }
}


private boolean checkValidUser(String usernameToCheck, String passwordToCheck) throws ClassNotFoundException, SQLException {
    // Assuming connectDB() establishes a database connection and 'con' is the Connection object
    connectDB();
    /////////
    
    String SQL = "SELECT * FROM user WHERE uname = ? AND upassword = ?;";
    try (PreparedStatement stmt = con.prepareStatement(SQL)) {
        stmt.setString(1, usernameToCheck);
        stmt.setString(2, passwordToCheck);
        
        try (ResultSet rs = stmt.executeQuery()) {
            // If the query finds a record, then the username and password are valid
            return rs.next();
        }
    } finally {
        // It's important to close the connection when you're done
        if (con != null && !con.isClosed()) {
            con.close();
        }
    }
}


public boolean isAdmin(String username) throws ClassNotFoundException {
    boolean isAdmin = false;
    String query = "SELECT upermission FROM user WHERE uname = ?";
    try {
        connectDB();
        PreparedStatement pstmt = con.prepareStatement(query);
        pstmt.setString(1, username);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            isAdmin = rs.getBoolean("upermission");
        }
        con.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return isAdmin;
}







//private boolean authenticate(String username, String password) {
	// Replace this with your actual authentication logic
//	return "admin".equals(username) && "password".equals(password);
//}



private boolean checkIfItemExists(int Item_id) throws SQLException, ClassNotFoundException {
    String SQL = "SELECT * FROM Item WHERE item_id = ?;";
    connectDB();
    try (
         PreparedStatement stmt = con.prepareStatement(SQL)) {
         
        stmt.setInt(1, Item_id);
        try (ResultSet rs = stmt.executeQuery()) {
            return rs.next();
        }
    }
}


		


        private void showAlert(String message) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        }

 
       

        
public void updateWlocation(int warehouse_id, String location) {
    		
    		try {
    			System.out.println("update  Warehouse set wlocation = '"+location + "' where warehouse_id = "+warehouse_id);
    			connectDB();
    			ExecuteStatement("update  Warehouse set wlocation = '"+location + "' where warehouse_id = "+warehouse_id+";");
    			con.close();
    			System.out.println("Connection closed");
    			
    			} catch (SQLException e) {
    				e.printStackTrace();
    			} catch (ClassNotFoundException e) {
    				e.printStackTrace();
    			}
    	}


private void getItemData() throws SQLException, ClassNotFoundException {
    // TODO Auto-generated method stub
    
    String SQL;
            
    connectDB();
    System.out.println("Connection established");

    SQL = "select item_id, iname, category, price, quantity, itemStatus from item order by item_id";
    Statement stmt = con.createStatement();
    ResultSet rs = stmt.executeQuery(SQL);
    
    while (rs.next()) {
        int itemId = rs.getObject(1) != null ? rs.getInt(1) : 0; // Default to 0 if null
        String itemName = rs.getString(2); // String can handle null
        String category = rs.getString(3); // String can handle null
        double price = rs.getObject(4) != null ? rs.getDouble(4) : 0.0; // Default to 0.0 if null
        String imageURL = "URL"; // Replace with actual logic to get URL
        int warehouseId = 1; // Replace with actual logic to get warehouse ID
        int quantity = rs.getObject(5) != null ? rs.getInt(5) : 0; // Default to 0 if null
        String itemStatus = rs.getString(6); // String can handle null
        
        itemData.add(new Item(
                itemId,
                itemName,
                category,
                price,
                imageURL,
                warehouseId,
                quantity,
                itemStatus
        ));
    }
    
    rs.close();
    stmt.close();
}



	public static void main(String[] args) {
		launch(args);
	}
}
	
	
	
