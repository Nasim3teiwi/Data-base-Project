package application;

public class User {
	private int user_id;
	private String uname;
	private String upermission;
	private String uemail;
	private String upassword;
	private String uaddress;
	
	
	public User(int user_id, String uname, String upermission, String uemail, String upassword, String uaddress) {
		this.user_id = user_id;
		this.uname = uname;
		this.upermission = upermission;
		this.uemail = uemail;
		this.upassword = upassword;
		this.uaddress = uaddress;
	}
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpermission() {
		return upermission;
	}
	public void setUpermission(String upermission) {
		this.upermission = upermission;
	}
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getUpassword() {
		return upassword;
	}
	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}
	public String getUaddress() {
		return uaddress;
	}
	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}
	
	
	
	
	
}
