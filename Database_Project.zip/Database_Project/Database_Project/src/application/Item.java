package application;

public class Item {
	private int item_id;
	private String iname;
	private String category;
	private double price;
	private String imageURL;
	private int warehouse_id;
	private int quantity;
	private String itemStatus;
	
	
	public Item(int item_id, String iname, String category, double price, String imageURL, int warehouse_id,
			int quantity, String itemStatus) {
		super();
		this.item_id = item_id;
		this.iname = iname;
		this.category = category;
		this.price = price;
		this.imageURL = imageURL;
		this.warehouse_id = warehouse_id;
		this.quantity = quantity;
		this.itemStatus = itemStatus;
	}


	public int getItem_id() {
		return item_id;
	}


	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}


	public String getIname() {
		return iname;
	}


	public void setIname(String iname) {
		this.iname = iname;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getImageURL() {
		return imageURL;
	}


	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}


	public int getWarehouse_id() {
		return warehouse_id;
	}


	public void setWarehouse_id(int warehouse_id) {
		this.warehouse_id = warehouse_id;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public String getItemStatus() {
		return itemStatus;
	}


	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	
	
	
	
	
	
}
